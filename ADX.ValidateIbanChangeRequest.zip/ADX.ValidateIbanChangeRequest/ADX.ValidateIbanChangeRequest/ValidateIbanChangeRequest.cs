﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADX.ValidateIbanChangeRequest
{
    public class ValidateIbanChangeRequest : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {

            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            var service = factory.CreateOrganizationService(context.UserId);
            var tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            string message = context.MessageName;

            if (message.ToLower() == "create"
                &&context.InputParameters.Contains("Target")
                && context.InputParameters["Target"] is Entity entity
                && entity.LogicalName == "adx_brokeribanchange")
            {
                bool isValid = ValidateCreateIban(service, entity);
                if (!isValid)
                {
                    throw new InvalidPluginExecutionException("An active IBAN change request already exists for this account.");
                }
                if (entity.Attributes.Contains("adx_newiban") && entity.Attributes.Contains("adx_oldiban"))
                {
                    string newIban = entity.GetAttributeValue<string>("adx_newiban");
                    string oldIban = entity.GetAttributeValue<string>("adx_oldiban");
                    if (newIban == oldIban)
                    {
                        throw new InvalidPluginExecutionException("The new IBAN cannot be the same as the old IBAN.");
                    }

                }
                else 
                {
                    throw new InvalidPluginExecutionException("Both old IBAN and new IBAN must be provided.");
                }

            }
            else if (message.ToLower() == "update" && context.InputParameters.Contains("Target")
                && context.InputParameters["Target"] is Entity entity2
                && entity2.LogicalName == "adx_brokeribanchange")
            {
                var currentIban = service.Retrieve("adx_brokeribanchange", context.PrimaryEntityId, new Microsoft.Xrm.Sdk.Query.ColumnSet("adx_oldiban", "adx_newiban"));
                if (entity2.Attributes.Contains("adx_newiban"))
                {
                    string newIban = entity2.GetAttributeValue<string>("adx_newiban");
                    string oldIban = currentIban.GetAttributeValue<string>("adx_oldiban");
                    if (newIban == oldIban)
                    {
                        throw new InvalidPluginExecutionException("The new IBAN cannot be the same as the old IBAN.");
                    }

                }
                else if (entity2.Attributes.Contains("adx_oldiban"))
                {
                    string oldIban = entity2.GetAttributeValue<string>("adx_oldiban");
                    string newIban = currentIban.GetAttributeValue<string>("adx_newiban");
                    if (newIban == oldIban)
                    {
                        throw new InvalidPluginExecutionException("The new IBAN cannot be the same as the old IBAN.");
                    }
                }
              
            }
        }
        public bool ValidateCreateIban(IOrganizationService service, Entity entity)
        {
            if(entity.Contains("adx_account"))
            {
                Guid accountId = entity.GetAttributeValue<EntityReference>("adx_account").Id;
                var query = new Microsoft.Xrm.Sdk.Query.QueryExpression("adx_brokeribanchange");
                query.ColumnSet = new Microsoft.Xrm.Sdk.Query.ColumnSet("adx_newiban", "adx_oldiban");
                query.Criteria.AddCondition("adx_account", Microsoft.Xrm.Sdk.Query.ConditionOperator.Equal, accountId);
                query.Criteria.AddCondition("statuscode", Microsoft.Xrm.Sdk.Query.ConditionOperator.Equal, 1);
                var results = service.RetrieveMultiple(query);
                if (results.Entities.Count > 0)
                {
                    return false;
                }
            }
                return true;
        }
    }
}

﻿using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk.Query;

namespace ADX.CRM.UpdateInvestor_InvstorMember
{

    public class UpdateInvestor : CodeActivity
    {
        [Input("Identification Number")]
        [RequiredArgument]
        public InArgument<string> IdentificationNumber { get; set; }
        protected override void Execute(CodeActivityContext context)
        {

            var workflowContext = context.GetExtension<IWorkflowContext>();
            var serviceFactory = context.GetExtension<IOrganizationServiceFactory>();
            var service = serviceFactory.CreateOrganizationService(workflowContext.UserId);
            ITracingService tracingService = context.GetExtension<ITracingService>();
            var query_adx_investornumber = IdentificationNumber.Get(context);

            var query = new QueryExpression("contact");
            query.ColumnSet.AddColumn("adx_investornumber");
            query.Criteria.AddCondition("adx_investornumber", ConditionOperator.Equal, query_adx_investornumber);
            var contactColl = service.RetrieveMultiple(query);
            if(contactColl != null && contactColl.Entities.Any())
            {
                var contact  = new EntityReference("contact",contactColl.Entities.First().Id);
                var investorMember = new Entity(workflowContext.PrimaryEntityName,workflowContext.PrimaryEntityId);
                investorMember["adx_investor"] = contact; 
                service.Update(investorMember);
            }

        }
    }
}

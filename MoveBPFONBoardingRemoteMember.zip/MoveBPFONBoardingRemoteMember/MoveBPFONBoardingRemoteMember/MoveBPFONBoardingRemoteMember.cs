﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Linq;

namespace MoveBPFONBoardingRemoteMember
{
    public class MoveBPFONBoardingRemoteMember : IPlugin
    {
        // Main entity (Onboarding)
        private const string ONBOARDING_ENTITY = "adx_remotememberonboarding";

        // Task entity
        private const string TASK_ENTITY = "adx_taskactivityv2";

        // Task lookup to onboarding (your field)
        private const string TASK_ONBOARDING_LOOKUP = "adx_memberonboarding";

        // Task order field
        private const string TASK_ORDER_FIELD = "adx_taskorder";
        private const string BPF_ENTITY_LOGICAL_NAME = "adx_remotemembertabadul";


        public void Execute(IServiceProvider serviceProvider)
        {
            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            var service = factory.CreateOrganizationService(context.UserId);
            var tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));

            try
            {
                // Registered on: adx_taskactivityv2 / Update / PostOperation
                if (!context.InputParameters.Contains("Target")) return;

                var target = context.InputParameters["Target"] as Entity;
                if (target == null || !string.Equals(target.LogicalName, TASK_ENTITY, StringComparison.OrdinalIgnoreCase))
                    return;

                // Use Post Image for final values
                if (context.PostEntityImages == null || !context.PostEntityImages.Contains("PostImage"))
                {
                    tracing.Trace("PostImage not found. Add Post Image with columns: statecode, statuscode, adx_memberonboarding.");
                    return;
                }

                var post = context.PostEntityImages["PostImage"];

                // 1) Only when task is Completed (Task: 0=Open, 1=Completed, 2=Canceled)
                var state = post.GetAttributeValue<OptionSetValue>("statecode")?.Value;
                if (state != 1)
                {
                    tracing.Trace("Task not completed. statecode={0}", state);
                    return;
                }

                // 2) Must be linked to onboarding
                var regarding = post.GetAttributeValue<EntityReference>(TASK_ONBOARDING_LOOKUP);
                if (regarding == null || !string.Equals(regarding.LogicalName, ONBOARDING_ENTITY, StringComparison.OrdinalIgnoreCase))
                {
                    tracing.Trace("No onboarding lookup on task.");
                    return;
                }

                var onboardingId = regarding.Id;

                // 3) Validate task order (previous task must be completed)
                if (!ValidateTaskOrder(service, context.PrimaryEntityId, onboardingId))
                    throw new InvalidPluginExecutionException("Previous Task is not completed yet.");

                // 4) If any remaining not-completed tasks, do not move
                if (HasAnyOpenTask(service, onboardingId))
                {
                    tracing.Trace("There are still open tasks for onboarding {0}", onboardingId);
                    return;
                }

                // 5) Move BPF to next stage (SAFE way)
                MoveBpfToNextStage(service, tracing, onboardingId);
            }
            catch (InvalidPluginExecutionException)
            {
                throw;
            }
            catch (Exception ex)
            {
                tracing.Trace("Unhandled exception: {0}", ex);
                throw new InvalidPluginExecutionException("MoveBPF plugin failed: " + ex.Message, ex);
            }
        }

        private static bool ValidateTaskOrder(IOrganizationService service, Guid taskId, Guid onboardingId)
        {
            var task = service.Retrieve(TASK_ENTITY, taskId, new ColumnSet(TASK_ORDER_FIELD));
            if (!task.Attributes.Contains(TASK_ORDER_FIELD))
                throw new InvalidPluginExecutionException("Task Order not found.");

            int taskOrderValue = task.GetAttributeValue<int>(TASK_ORDER_FIELD);
            if (taskOrderValue <= 1) return true;

            // Check previous task (order - 1) is completed
            var qe = new QueryExpression(TASK_ENTITY)
            {
                ColumnSet = new ColumnSet(false),
                TopCount = 1
            };

            qe.Criteria.AddCondition(TASK_ONBOARDING_LOOKUP, ConditionOperator.Equal, onboardingId);
            qe.Criteria.AddCondition(TASK_ORDER_FIELD, ConditionOperator.Equal, taskOrderValue - 1);
            qe.Criteria.AddCondition("statecode", ConditionOperator.NotEqual, 1); // not Completed

            var res = service.RetrieveMultiple(qe);
            return !res.Entities.Any();
        }

        private static bool HasAnyOpenTask(IOrganizationService service, Guid onboardingId)
        {
            var qe = new QueryExpression(TASK_ENTITY)
            {
                ColumnSet = new ColumnSet(false),
                TopCount = 1
            };

            qe.Criteria.AddCondition(TASK_ONBOARDING_LOOKUP, ConditionOperator.Equal, onboardingId);
            qe.Criteria.AddCondition("statecode", ConditionOperator.NotEqual, 1); // not Completed

            var res = service.RetrieveMultiple(qe);
            return res.Entities.Any();
        }

        /// <summary>
        /// SAFE BPF move:
        /// - Gets the correct active process instance for the onboarding record (no guessing entity/lookup)
        /// - Gets active path stages for that instance
        /// - Moves to the next stage from that same path (so no "StageIdIsNotValid")
        /// </summary>
        private static void MoveBpfToNextStage(IOrganizationService service, ITracingService tracing, Guid onboardingId)
        {
            // 1) Get active process instance id for onboarding record
            var procResp = (RetrieveProcessInstancesResponse)service.Execute(new RetrieveProcessInstancesRequest
            {
                EntityId = onboardingId,
                EntityLogicalName = ONBOARDING_ENTITY
            });

            var instances = procResp?.Processes?.Entities;
            if (instances == null || instances.Count == 0)
                throw new InvalidPluginExecutionException("No process instance found for this onboarding record.");

            var activeInstanceRow =
                instances.FirstOrDefault(e => e.GetAttributeValue<OptionSetValue>("statuscode")?.Value == 1)
                ?? instances.FirstOrDefault();

            if (activeInstanceRow == null)
                throw new InvalidPluginExecutionException("Cannot determine active process instance.");

            Guid processInstanceId = activeInstanceRow.Id;

            // 2) Retrieve the REAL BPF instance record from your BPF entity
            //    (NOT businessprocessflowinstance)
            var bpf = service.Retrieve(
                BPF_ENTITY_LOGICAL_NAME,
                processInstanceId,
                new ColumnSet("activestageid", "traversedpath")
            );

            // 3) Read current stage safely (Guid or EntityReference)
            Guid currentStageId = ReadStageId(bpf, "activestageid")
                ?? throw new InvalidPluginExecutionException("BPF instance has no activestageid.");

            tracing.Trace("BPF entity: {0}", BPF_ENTITY_LOGICAL_NAME);
            tracing.Trace("BPF instance: {0}", processInstanceId);
            tracing.Trace("Current stage: {0}", currentStageId);

            // 4) Get active path stages for THIS instance (guaranteed valid stages)
            var pathResp = (RetrieveActivePathResponse)service.Execute(new RetrieveActivePathRequest
            {
                ProcessInstanceId = processInstanceId
            });

            var stages = pathResp?.ProcessStages?.Entities;
            if (stages == null || stages.Count == 0)
                throw new InvalidPluginExecutionException("RetrieveActivePath returned no stages.");

            int idx = -1;
            for (int i = 0; i < stages.Count; i++)
            {
                if (stages[i].Id == currentStageId)
                {
                    idx = i;
                    break;
                }
            }

            if (idx < 0)
                throw new InvalidPluginExecutionException("Current stage not found in active path.");

            if (idx >= stages.Count - 1)
            {
                tracing.Trace("Already at last stage. No move needed.");
                return;
            }

            Guid nextStageId = stages[idx + 1].Id;
            tracing.Trace("Next stage: {0}", nextStageId);

            // Build CLEAN traversed path from ACTIVE PATH only (no invalid stages)
            var cleanTraversed = string.Join(",",
                stages
                    .Take(idx + 2)   // up to current + next stage
                    .Select(s => s.Id.ToString())
            );

            var update = new Entity(BPF_ENTITY_LOGICAL_NAME, processInstanceId);
            update["activestageid"] = new EntityReference("processstage", nextStageId);
            update["traversedpath"] = cleanTraversed;

            service.Update(update);


            // 6) Optional: your custom lookup stage logic
            MoveStageLookup(service, onboardingId);
        }


        /// <summary>
        /// Your custom "stage lookup" logic (adx_thestage) based on adx_stagesorder + 1
        /// </summary>
        private static void MoveStageLookup(IOrganizationService service, Guid onBoardingId)
        {
            var query = new QueryExpression(ONBOARDING_ENTITY)
            {
                ColumnSet = new ColumnSet("adx_thestage")
            };
            query.Criteria.AddCondition(ONBOARDING_ENTITY + "id", ConditionOperator.Equal, onBoardingId); // may not work if id name differs

            // Safer: use real PK name:
            // query.Criteria.AddCondition("adx_remotememberonboardingid", ConditionOperator.Equal, onBoardingId);

            // Link stage entity
            var rms = query.AddLink("adx_remotememberstages", "adx_thestage", "adx_remotememberstagesid");
            rms.EntityAlias = "RMS";
            rms.Columns.AddColumn("adx_stagesorder");

            var result = service.RetrieveMultiple(query).Entities.FirstOrDefault();
            if (result == null) return;

            int? stageOrder = null;
            if (result.Contains("RMS.adx_stagesorder"))
            {
                stageOrder = result.GetAttributeValue<AliasedValue>("RMS.adx_stagesorder")?.Value as int?;
            }

            if (stageOrder == null) return;

            var nextStageQe = new QueryExpression("adx_remotememberstages")
            {
                ColumnSet = new ColumnSet(false),
                TopCount = 1
            };
            nextStageQe.Criteria.AddCondition("adx_stagesorder", ConditionOperator.Equal, stageOrder.Value + 1);

            var stageResult = service.RetrieveMultiple(nextStageQe);
            if (!stageResult.Entities.Any()) return;

            var newStageId = stageResult.Entities.First().Id;

            var toBeUpdated = new Entity(ONBOARDING_ENTITY, onBoardingId);
            toBeUpdated["adx_thestage"] = new EntityReference("adx_remotememberstages", newStageId);
            service.Update(toBeUpdated);
        }
        private static Guid? ReadStageId(Entity entity, string attributeName)
        {
            if (!entity.Attributes.Contains(attributeName) || entity[attributeName] == null)
                return null;

            if (entity[attributeName] is Guid g)
                return g;

            if (entity[attributeName] is EntityReference er)
                return er.Id;

            return null;
        }

    }

    internal static class ListExt
    {
        // helper for older .NET where List<T>.FindIndex exists only on List, not EntityCollection
        public static int FindIndex(this System.Collections.Generic.IList<Entity> list, Func<Entity, bool> predicate)
        {
            for (int i = 0; i < list.Count; i++)
                if (predicate(list[i])) return i;
            return -1;
        }
    }

}

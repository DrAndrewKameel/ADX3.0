﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GetEmailMobileByNIN
{
    public class GetEmailMobileByNIN : CodeActivity
    {
        [Input("NIN")]
        [RequiredArgument]
        public InArgument<string> NIN { get; set; }

        [Output("Email")]
        public OutArgument<string> Email { get; set; }


        [Output("Mobile")]
        public OutArgument<string> Mobile { get; set; }
        protected override void Execute(CodeActivityContext context)
        {
            var workflowContext = context.GetExtension<IWorkflowContext>();
            var serviceFactory = context.GetExtension<IOrganizationServiceFactory>();
            var service = serviceFactory.CreateOrganizationService(workflowContext.UserId);
            ITracingService tracingService = context.GetExtension<ITracingService>();
            var nin = NIN.Get<string>(context);
            var fetchXmlCurrentUserCases = $@"
                <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                    <entity name='contact'>
                        <attribute name='fullname'/>
                        <attribute name='contactid'/>
                        <attribute name='adx_investornumber'/>
                        <attribute name='mobilephone'/>
                        <attribute name='emailaddress1'/>
                        <attribute name='createdon'/>
                        <attribute name='adx_passportnumber'/>
                        <order attribute='fullname' descending='false'/>
                        <filter type='and'>
                            <condition attribute='adx_investornumber' operator='eq' value='{nin}'/>
                        </filter>
                    </entity>
                </fetch>";

            var contactColl = service.RetrieveMultiple(
                new FetchExpression(
                    fetchXmlCurrentUserCases));
            tracingService.Trace("Start \t " + contactColl.Entities.Count);
            if (contactColl == null || contactColl.Entities.Count == 0)
            {
                Email.Set(context, "Not Found");
                Mobile.Set(context, "Not Found");
            }
            else
            {
                var email = contactColl.Entities[0].Contains("emailaddress1") ?
                    contactColl.Entities[0]["emailaddress1"].ToString() : "Null";

                var mobile = contactColl.Entities[0].Contains("mobilephone") ?
                    contactColl.Entities[0]["mobilephone"].ToString() : "Null";

                Email.Set(context, email);
                Mobile.Set(context, mobile);

            }

        }
    }
}


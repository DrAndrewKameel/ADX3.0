﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADX.CRM.GetDDSByNIN
{
    public class GetDDSByNIN : CodeActivity
    {
        [Input("NIN")]
        [RequiredArgument]
        public InArgument<string> NIN { get; set; }

        [Output("Status Code")]
        public OutArgument<int> StatusCode { get; set; }
        [Output("Message")]
        public OutArgument<string> Message { get; set; }
        [Output("Justification")]
        public OutArgument<string> Justification { get; set; }
        protected override void Execute(CodeActivityContext context)
        {
            var workflowContext = context.GetExtension<IWorkflowContext>();
            var serviceFactory = context.GetExtension<IOrganizationServiceFactory>();
            var service = serviceFactory.CreateOrganizationService(workflowContext.UserId);
            ITracingService tracingService = context.GetExtension<ITracingService>();
            var nin = NIN.Get<string>(context);
            var fetchXmlCurrentUserCases = $@"
                <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                    <entity name='contact'>
                        <attribute name='fullname'/>
                        <attribute name='contactid'/>
                        <attribute name='adx_investornumber'/>
                        <order attribute='fullname' descending='false'/>
                        <filter type='and'>
                            <condition attribute='adx_investornumber' operator='eq' value='{nin}'/>
                        </filter>
                    </entity>
                </fetch>";

            var contactColl = service.RetrieveMultiple(
                new FetchExpression(
                    fetchXmlCurrentUserCases));
            tracingService.Trace("NIN = " + nin);
            if (contactColl == null || contactColl.Entities.Count == 0)
            {
                tracingService.Trace("1");
                StatusCode.Set(context, 400);
                tracingService.Trace("11");
                Message.Set(context, "Not Found");
                tracingService.Trace("111");
                Justification.Set(context, "there is no contact with " + nin + " exist");
                tracingService.Trace("1111");
            }
            else
            {
                tracingService.Trace("2");
                var contactId = contactColl.Entities[0].Id;
                var fetchXmlIpoTranscation = $@"<?xml version=""1.0"" encoding=""utf-16""?>
                            <fetch>
                              <entity name=""adx_ipopaymenttransactionreference"">
                                <attribute name=""adx_contact"" />
                                <attribute name=""adx_ddsreference"" />
                                <attribute name=""adx_investornin"" />
                                <filter>
                                  <condition attribute=""adx_contact"" operator=""eq"" value=""{contactId}"" />
                                  <condition attribute=""statecode"" operator=""eq"" value=""0"" />
                                </filter>
                              </entity>
                            </fetch>";
               
                var ipoColl = service.RetrieveMultiple(
                    new FetchExpression(
                   fetchXmlIpoTranscation));
                tracingService.Trace("3");
                if (ipoColl.Entities.Any())
                {
                    tracingService.Trace("4");
                    var etn = ipoColl.Entities.First();
                    if(etn.Contains("adx_ddsreference"))
                    {
                        StatusCode.Set(context, 200);
                        Message.Set(context, "sucess");
                        Justification.Set(context, etn["adx_ddsreference"].ToString() );
                    }
                    else
                    {
                        StatusCode.Set(context, 400);
                        Message.Set(context, "Not Found");
                        Justification.Set(context, "DDS is empty for this " + nin );
                    }
                  
                }
                else
                {
                    tracingService.Trace("5");
                    StatusCode.Set(context, 400);
                    Message.Set(context, "Not Found");
                    Justification.Set(context, "there is no IPO with " + nin + " exist");
                }

            }


        }
    }
}

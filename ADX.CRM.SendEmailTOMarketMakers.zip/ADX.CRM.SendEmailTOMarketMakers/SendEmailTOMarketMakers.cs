﻿using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk.Query;
using System.Net.NetworkInformation;
using System.Web.UI.HtmlControls;

namespace ADX.CRM.SendEmailTOMarketMakers
{
    public class SendEmailTOMarketMakers : CodeActivity
    {
        [Input("From")]
        [ReferenceTarget("queue")]
       
        public InArgument<EntityReference> From { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            var workflowContext = context.GetExtension<IWorkflowContext>();
            var serviceFactory = context.GetExtension<IOrganizationServiceFactory>();
            var service = serviceFactory.CreateOrganizationService(workflowContext.UserId);
            ITracingService tracingService = context.GetExtension<ITracingService>();
            tracingService.Trace($"Start");

            EntityReference fromRef = From.Get(context);
            var accounts = GetALLMarketMakers(service);
           
            if (accounts.Entities == null || accounts.Entities.Count == 0) { return; } // make sure there are entities
            foreach (var acc in accounts.Entities)
            {
                var name = acc.Contains("name") ? acc["name"].ToString() : "";
                var code = acc.Contains("adx_marketmakercode") ? acc["adx_marketmakercode"].ToString() : "";
                var secColl = GetSecurityObligationsByAccount(service, acc);
             
                if (secColl == null) continue;
                var table = BuildTable(secColl);
                var email = BuildEmail(table, name);
                SendEmail(service, email, fromRef, acc.Id,code,name);
            
            }


        }
        public EntityCollection GetALLMarketMakers(IOrganizationService service)
        {
          
            var query = new QueryExpression("account");
            query.ColumnSet.AddColumns("adx_marketmakercode", "name", "emailaddress1");
            query.Criteria.AddCondition("adx_accountprofiletype", ConditionOperator.Equal, 4);
            query.Criteria.AddCondition("emailaddress1", ConditionOperator.NotNull);
            query.Criteria.AddCondition("adx_marketmakercode", ConditionOperator.NotNull);
            var accColl = service.RetrieveMultiple(query);
           
            return accColl;

        }
        public EntityCollection GetSecurityObligationsByAccount(IOrganizationService service, Entity acc)
        {
            var query = new QueryExpression("adx_securityobligation");
            query.ColumnSet.AddColumns(
                "adx_actualresponserate",
                "adx_marketmakercode",
                "adx_marketmakername",
                "adx_obligatedresponserate",
                "adx_name");
            query.Criteria.AddCondition("adx_marketmakername", ConditionOperator.Equal, acc.Id);

            var securityOblColl = service.RetrieveMultiple(query);
            if (securityOblColl != null && securityOblColl.Entities.Any()) { return securityOblColl; }
            return null;


        }
        public StringBuilder BuildTable(EntityCollection secColl)
        {

            StringBuilder htmlTable = new StringBuilder();

            htmlTable.Append(@"
                            <style>
                                table {
                                    border-collapse: collapse;
                                    width: 100%;
                                    font-family: Arial, sans-serif;
                                }
                                th, td {
                                    border: 1px solid #999;
                                    padding: 8px;
                                    text-align: left;
                                }
                                th {
                                    background-color: #dbe5f1;
                                }
                            </style>
                            ");

            htmlTable.Append("<table>");
            htmlTable.Append("<tr><th>Security</th><th>Obligated response Rate %</th><th>Actual Response Rate %</th></tr>");

            foreach (var item in secColl.Entities)
            {
                var name = item.Contains("adx_name") ? item["adx_name"].ToString() : "";
                var obligationRate = item.Contains("adx_obligatedresponserate") ? item["adx_obligatedresponserate"].ToString() : "";
                var actualRate = item.Contains("adx_actualresponserate") ? item["adx_actualresponserate"].ToString() : "";

                htmlTable.Append($"<tr><td>{name}</td><td>{obligationRate}</td><td>{actualRate}</td></tr>");
            }

            htmlTable.Append("</table>");


            return htmlTable;
        }
        public string BuildEmail(StringBuilder htmlTable, string AccountName)
        {

            string today = DateTime.Now.ToString("dd MMMM yyyy");

            string emailBody = $@"  
                <p>Dear {AccountName},</p>
                <p>We would like to inform you that the Market Maker Obligations, as outlined in the Market Making Agreement, were not met on <b>{today}</b> for the following securities:</p>
                <p><b>List of all securities not meeting the market maker obligation on the trading date:</b></p>
                 {htmlTable}
                <style>
                    table {{
                        border-collapse: collapse;
                        width: 100%;
                        font-family: Arial, sans-serif;
                    }}
                    th, td {{
                        border: 1px solid #999;
                        padding: 8px;
                        text-align: left;
                    }}
                    th {{
                        background-color: #dbe5f1;
                    }}
                </style>

         
                ";

            return emailBody;
        }
        public void SendEmail(IOrganizationService service,string emailBody,EntityReference fromRef,Guid accId,string code, string accountName)
        {
            string today = DateTime.Now.ToString("dd MMMM yyyy");

            var email = new Entity("email");
            email["subject"] = $"{code} - {accountName}, MM Obligations Non-Compliance on Trade date {today}";
            email["description"] = emailBody;
            email["directioncode"] = true; // outgoing

            // Set sender, recipient (To)
            email["from"] = new EntityCollection(new List<Entity>
            {
                new Entity("activityparty")
                {
                    ["partyid"] =new EntityReference("queue",new Guid("15825529-dd35-ee11-bdf4-6045bd6a52bc"))
                }
            }) ;
            email["to"] = new EntityCollection(new List<Entity>
            {
                new Entity("activityparty")
                {
                    ["partyid"] = new EntityReference("account", accId)
                }
            });
           

            var emailId = service.Create(email);

            // Send the email
            var sendRequest = new OrganizationRequest("SendEmail")
            {
                ["EmailId"] = emailId,
                ["TrackingToken"] = "",
                ["IssueSend"] = true
            };
            service.Execute(sendRequest);

        }
        public class SecurityObligation
        {
            public decimal? ObligatedRate { get; set; }
            public decimal? ActualRate { get; set; }
            public string Code { get; set; }
        }

    }
}

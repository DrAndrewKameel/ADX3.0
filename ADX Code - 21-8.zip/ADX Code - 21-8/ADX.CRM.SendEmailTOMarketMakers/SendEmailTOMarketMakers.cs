﻿using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Xrm.Sdk;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk.Query;
using System.Net.NetworkInformation;
using System.Web.UI.HtmlControls;

namespace ADX.CRM.SendEmailTOMarketMakers
{
    public class SendEmailTOMarketMakers : CodeActivity
    {
        [Input("From")]
        [ReferenceTarget("queue")]

        public InArgument<EntityReference> From { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            var workflowContext = context.GetExtension<IWorkflowContext>();
            var serviceFactory = context.GetExtension<IOrganizationServiceFactory>();
            var service = serviceFactory.CreateOrganizationService(workflowContext.UserId);
            ITracingService tracingService = context.GetExtension<ITracingService>();
            tracingService.Trace($"Start");

            EntityReference fromRef = From.Get(context);
            var accounts = GetALLMarketMakers(service);

            if (accounts.Entities == null || accounts.Entities.Count == 0) { return; } // make sure there are entities
            foreach (var acc in accounts.Entities)
            {
                var name = acc.Contains("name") ? acc["name"].ToString() : "";
                var code = acc.Contains("adx_marketmakercode") ? acc["adx_marketmakercode"].ToString() : "";
                var email2 = acc.Contains("emailaddress2") ? acc["emailaddress2"].ToString() : null;
                var email3 = acc.Contains("emailaddress3") ? acc["emailaddress3"].ToString() : null;

                var secColl = GetSecurityObligationsByAccount(service, acc);
                if (secColl == null) continue;

                var table = BuildTable(secColl);
                var email = BuildEmail(table, name);
                SendEmail(service, email, fromRef, acc.Id, code, name, email2, email3);

            }


        }
        public EntityCollection GetALLMarketMakers(IOrganizationService service)
        {

            var query = new QueryExpression("account");

            // Add columns to query.ColumnSet
            query.ColumnSet.AddColumns("adx_marketmakercode", "emailaddress2", "emailaddress3", "name");

            // Add filter query_And1 to query.Criteria
            var query_And1 = new FilterExpression();
            query.Criteria.AddFilter(query_And1);

            // Add conditions to query_And1
            query_And1.AddCondition("adx_accountprofiletype", ConditionOperator.Equal, 4);
            query_And1.AddCondition("adx_marketmakercode", ConditionOperator.NotNull);

            // Add filter query_Or1 to query.Criteria
            var query_Or1 = new FilterExpression(LogicalOperator.Or);
            query.Criteria.AddFilter(query_Or1);

            // Add conditions to query_Or1
            query_Or1.AddCondition("emailaddress2", ConditionOperator.NotNull);
            query_Or1.AddCondition("emailaddress3", ConditionOperator.NotNull);


            var accColl = service.RetrieveMultiple(query);

            return accColl;

        }
        public EntityCollection GetSecurityObligationsByAccount(IOrganizationService service, Entity acc)
        {
            var query = new QueryExpression("adx_securityobligation");
            query.ColumnSet.AddColumns(
                "adx_actualresponserate",
                "adx_marketmakercode",
                "adx_marketmakername",
                "adx_obligatedresponserate",
                "adx_name");
            query.Criteria.AddCondition("adx_marketmakername", ConditionOperator.Equal, acc.Id);
            query.Criteria.AddCondition("createdon", ConditionOperator.Today);
            // Add orders
            query.AddOrder("adx_name", OrderType.Ascending);

            var securityOblColl = service.RetrieveMultiple(query);
            if (securityOblColl != null && securityOblColl.Entities.Any()) { return securityOblColl; }
            return null;


        }
        public StringBuilder BuildTable(EntityCollection secColl)
        {

            StringBuilder htmlTable = new StringBuilder();

            htmlTable.Append(@"
                            <style>
                                table {
                                    border-collapse: collapse;
                                    width: 600px;
                                    font-family: Arial, sans-serif;
                                    font-size: 13px; 
                                }
                                th, td {
                                    border: 1px solid #999;
                                    padding: 8px;
                                    text-align: left;
                                }
                                th {
                                    background-color: #dbe5f1;
                                }
                            </style>
                            ");

            htmlTable.Append("<table>");
            htmlTable.Append("<tr><th>Security</th><th>Obligated response Rate %</th><th>Actual Response Rate %</th></tr>");

            foreach (var item in secColl.Entities)
            {
                string obligationRate = "";
                var name = item.Contains("adx_name") ? item["adx_name"].ToString() : "";
                var responseRate = item.Contains("adx_obligatedresponserate") ? item["adx_obligatedresponserate"].ToString() : "";
                if (decimal.TryParse(responseRate, out decimal parsedDecimal))
                {
                    obligationRate = ((int)parsedDecimal).ToString();
                    // Use responseRate here
                }
                else obligationRate = "";
                var actualRate = "";
                var actRate = item.Contains("adx_actualresponserate") ? item["adx_actualresponserate"].ToString() : "";
                if (decimal.TryParse(actRate, out decimal parsedDecimal2))
                {
                    actualRate = parsedDecimal2.ToString("0.00");

                }
                else actualRate = "";
                htmlTable.Append($"<tr><td>{name}</td><td>{obligationRate}</td><td>{actualRate}</td></tr>");
            }

            htmlTable.Append("</table>");


            return htmlTable;
        }
        public string BuildEmail(StringBuilder htmlTable, string AccountName)
        {

            string today = DateTime.Now.ToString("dd MMMM yyyy");

            string emailBody = $@"  
               <div style='text-align: left;'>
                    <img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAAmCAYAAACBFtRsAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAABJnSURBVHgB7V3NbhvXFT738ieqHcDjReI4G1NPYPoJRKFR0q4s7WrFgKknkLgpYCWBKLSWgy5K6QkkA7HcnahVGzuB6Ccw8wRmgAKpnUUYtFJlcubefufODHlnNOKPRKmJxQ+gOJy5c39mzv85MxJ0QpQfVnKdH2+oWS6XmonHeiF23knxh7//kAu3JyYOm1vTk6fuM0R8LeX7pQaNcWGQphOipWmPNOXMjwyt4m85PNZW9EITOX07yRAtP6iQIGqifUMIYsKuK6LnIk2NtT+W6jQAUunUpiZdMPNyLzWLez/c2pq+3qBTgpkjtpYGPpM0xoWBpBMARF3sMIePxXK50mEIENQGDYGAAPNaUwGfJaFph9r0AuO8/OxBZfPzh5VCr/M911sQJEKt4bTd1CaNAGCOFZvRlaRpGuNC4UQMAkl/L7bLeZOlQvgj26Z1Gg1yINCiUrTHzGIYMwF/+/31hiavw5SsTe78419LdArwWDx2Z4eijS/H5tWFg6AhwWZHS9HLIx0Jqj1YLk3b7SINLH/DaJt3fMmMvhypzLYDCZ1HRzdB4vmYhrLRyEKSJ/kC809fvcSKwvOa2fTB5En8EbNG24TkMdt0axT+0hi/LgzNIGzyRCSrjQzdGtRv6AdI8DyYroCxFhOYpakVLTz8olS1d9599kNBkdwLfwuS649n3ivRkEhY48LaZ6UtGuPCYWgTS4uuKQVpHyFQ+A2zNCKAIOvQSOtryyV2ihdA7Q3rsCMk7dxfq0TMqK9mrtdIaMvUUkt3n/1YoCGw/JdKPsocYmvMHBcXQzFI3DmXnt5g08pqEnHWRwUmUCXgIAuKMCSc+cr9P1UiTJlNvVO2HHZSQm0W914OPicXAYIuGkrqVRrjwmIoBok5540/f1GqCY9sAoo466MEO8jQJnPsLNv7oUk2bX9na/pqUwi90GkAhm61Lg3ksC8/rKzEzLnVsWP+y8P809dFNqfpHDAwgzARchjW2mUYwzAJUdPqcJHOEGtflBAG1o+sXU5bUySs+9VH16rQIjXqTmoFuZFcr34Nk6luLkcIURubVr9MSClu0zlhYAbhnID9GxGnWrht5z2YidiOpzNExhVLYMq6Pebnf4rmSmK5EeqXG8H6diLn21ronMBSsbj3Os/M3EtCFvd+cua/fV3kbf4exITkPu9882pgH/HTZ68rkNT5uzgnFC7+9suRmtAn6VNr77nSqXOJKA7MIBHnHI6rbXpw3sPWIqN01pPA4VahKBKd0qkoA3NuRJHbMf965UaCnEeXqdXoTCsm9Pmv/1UFwb3o19bTsthy9WxLpQpKpO4d1+7w8NAhpX2Gx/fh4cQRAmOinv/m9SbGNVE916Uc7lGFBgAzoBY6x9tai0WeT7jtuu+OVPgpzInnP//sVZkZcrCz5G1KUWJbXu+dgLlpBBiIQY445ypi4hiC1cIyac7IWbfBph00R2ceSVrkycyH67apJVJiJS6tjGklIszVgBlXphGBI2vbn3wwCwbdpXMEl9oc/Hu/hOsydJjb+HFaOMrzzi/vo0V1++P3T50i4PX+9z/7q6PoizFQLRY75xg4hHHO4204ogWzK9QcobNepTNEShNHtzqSFuMX8FWz2wjyVjXJQjivtneZpWjHfIL/Mmsz/6jLSeaf/bgiSM0GGqp85PhT31TCDd1KOp8Zuu1eNuYf3/xBb7zJCQm5iZOaGAPr9RLHZFMK2mJWaFm1c0ahBhkWd795vYh5zuL85vZH1+boyHp+clpea9M+JtPpCgmVn//mFYcd53iN3I8ivcQC7vFH75v7heObqq2OjSqy1my7VLn07iUH1sKjJ7/7YD3sB/cYiWM1169Gj02+dErVW+2UAz/0Xl8NcpxzHkfgrHdu3lk76+GYdn4EjDwVb3MkN6J10c6NZFq01elDjTZqxWYDronzeObarWMbMSH2IEZmaEVqlxkd6xu4xgxCoSK1BGGpXdKqnDQmE4NWajKbymJ+ujisWeL7TN3gh2FKrcs8V6JkE8iYh/FjSn0HhpnEPB+BcBaDfoq8j01j634VqAdanljSSj+XpEpsLZiutV4HU02Dhr9rtUWiic3V4GA+Ux0SmpRSeA5XdPTVIL2c8zggJdmMyPsD+c76qDLrdPygPOZiOCabdvGSEM6NtNqt22EZSpAbucVlKNwWptkC1rWZ9UZWQxZA8TUpGCmNrcSkpaCb/MXH0OYGPg2zG1rNONWs4YTYhTZAlE2bfZBs7IMkjsgaS7kuTE/RhH0/JSh1BUR3xdYgEUhxw3XdvL8pHGYS/oYgcdKZTF6RlxNK3vTnpxy7+EJTasX1jPBpWOtpum1qyDQ5SetFXonXYY55Av1pcqSUtWD9VyxtnjP7tMK9VMwkLNwSzfY7X7+aTUnF62XJfFPJVIPH8KcjmjKVKiAdgNPpRtKctCmUVQ5fW8whB/NySlPaMWKG+qCXcx7HeTvrASIM2Lp0tIaLbWop1LG5EdZEbFqNutZqe+Z62Ugz8qABdAmMee/Ih1TTRGWwDbOkoZVXz8pMVWn1Ha7lbRwr4WYXcHunpIBpGGzjzm+ZQfDNz8B0R/W1BUfxcO5VCgRWOk0N3Hhj8oLBbvA3h8MhtTcwh0UQhgNpixySKgRzqYI5brNUVxqkbPZRndt0LmOC5sMYTQ6QYL2rSevlufMxT3uzvD5O/obH0J+DedSM1tfKXC8mXhD+zXBO/lrVrlReIxwTYd9FJMQcFoTggu8xRicMjOtwC4ydp8CUTpqTFuomj8fXFhpoF/fgOe/jufSsxQqqZztqXSqaTvI/Iuesre9ggiFjNME0k2dZ5Fd+UMm3iDoRItzEuYfLpUTfB2p0x1yoALBJJ0fx3MhJweZJy03Dh1L5bPpgYRQPekFb/QSpOffVzHs18xuRLJhRP29//IERCOx/wFSrMOEwId/9FhpHqyKIYzdsMyjmn/5QBHWuhIzHvoz2vNKTTz481vdkH6Ttuiv9auQ+fcYRRwkBAfPLmju+6nE/DKbsjiDZCPsM/aDHM+9Ps7nGmo73s9DgNdMQ6GliDeKcx3HezvqhpKZU3d8wTY6NnsHWXmi7bVblpk2QG/k/PuMx0STd3oV2ez6qpyBZ48Aw4PBuw6wTzunB/n9tZ7m+/5/9yepcMB4I0HeMrw1tCm9/fH0L9nstlRYwTRD1gq3/t99/2Oh1DmtzEG3fiB60TN11vapN0Iiq1eDDHL1OWiAQo3aw5nygCUm5yqyZ8yXwJ1aNVjoBjtUgCWXtA1e0fvag8iLMK8TL4EcN9jlaGfrJ2nXsPNn+hDnRqfYFNW0MKzV/LWDHk4mpwwhniOAxgzoT6qjCqydB+Oj1sFqiF47VIMM453Gcp7N++I55nmQgsHNOujPJBiRrmd5SjJJI+gHaZ5J+ATiLNR/rpA/jnMdxns76hIqaVGCWRlK7+W9fxQoR1aotXe+vVc4joGDAvke/2rD+fbx0+oVlk9rwvlGXi/Tr/zzGHPaxhkGRqEHimXPYg7PLa72fCwfqptqW/Mz6/T9Xdq3qX86sr5+Fs+4qzNNic/UOHRnDd4atJJ0QW4gwbYU/P//yr4vKw7QfVupn8dYSkyxExCdMeL1py7Lwcy/lgc5HggyOcI63uXqAE3wtdXkW6+a8z7E1Y9wmuAcdE7fV/k049nq4j8szOCIVTxaeBG33N0Xt084Sh02fIFLWameQd8mwRTI3SB++I9/u1Maxs92rvetO5I11cAYv1EhkkJhz7r9UQfd9S0mOSz1CRz6W5T4zZz3InodoJplybVd2CxFhWinX6yQ7A1+L/ZCwKnik/pLPnGoJ17DJUi6MLiHSdOXTZz8uISxZ8zPHnME9wLEJ540n80xYVjcFtF/wQ6x6B1livhdGEAR9NJlp/ExyepZ/ZzP71VZgetptJEKl6XS30I/HVcivbM9cm5zd8aV82A+IrsHz8LP57xb5WCbtVsP5cYQo7Mt1BTvHuUyaanCuHdOvpp35b18vZKWHfcokawM/sBCWloS/EQ6vhY40JxNlRuZM8pCC7Ltqz2blPq7J5Zw/8/1GOCeMXu+uRTj+tYjOmQMib7xWIUWcl/Tb8LGwqkBK3fSvP9PLu8XO9Yrf0ITM+cCwold+Zt16mOrMMuuC7NLn5/HDfAHsQkRIyg3bVrVLTXjd8QewTotWO1UwT176+YRO39qEwj0WRnvsXHLRHhcC9ioqZIKCJuKH1ApBJ3ktOXdBpjjPnAuihp2ZD/M8nIn22+hFvhZhQWTYJ4ilwYlHDgc7zoRjiBEChfuRmlaYgE15jlZmLHt+neJKfDDODnIHDm+bQkuT4PPB53ColRkPIeVN5HPqvG7zG0ETafIrsepcCGTWnJxkNbVhiu7xPLiU5PDQa/I23IApnlPQnvvO8zrvmBDxhMPHFOx7jlYy0/HbciAMCmEbnzk0tLtywutv+tVejq/h/NevykcYJO6ck6/CB/podcSR3+0SxOjL4M3rgKIPOEU0lLHzpe6uB9rjycwH63abSKkJmQewKqMstOSbEWw4+Nzr2OKCHj3251KXWb9aduA+pbxiNpT+fvu3RhLWpek/dZNLJSAFblDKTwZyLRO3MYETebQUh5kuSKb9DMZ44ULKEr9NBv2AAB2W7obJSKwHYyUCuZbn9rUNtYF9jqkKln45B8dPgyrhKhOnlkeTjhJCJSxINTV1Whcxp4b/FhtdAANvdPrHfk7MQmshwYprQSlHaoFEZyrfSWhyG0Qt+VpwG7MuCBy+D2CekNFglkokDsWUkGIqYmIxYbTJdqj5eeylLTohmPjaGevdUr6zPrJoFhgy8oRjPLzb9pAg0t0Lrzx1xHyySk3C8G+unTVC4lS2OGP+6T/5XV8OiOI561CBLPIb2Oh8DDdoiqU+3zypJN/wpinDIHmDEqpINHl5mEp5dLKCTC/mBmMhJe3wNhe2LEmSCyC2qY5WJJ0PykduKuVCYMmCfQ4LEddN59Cwyhl1U6jnSpgl3sLhof+myrZ7eYqZG5quCS0IQpK+8++P0zAdxebSvQYcJPDLXDj7rUg2uW8e8/FH79VwHMwNTaCNhdEVcPwSQZ0mHDO0o41Wgmms5SLmvNp2Ba4Z3cacGpxFj48LTbYCc/JRSoobuC5TSXNjLSkodRu+UgPj54OcR52ZMps5MOZcRIMgnzCrrRelxcvah4Upgyey+xhZGXzCe6siczWmFSSOdXz1uDCg8ZtU5KGvpXjp/EmgtcyxhGIpxx+lfN9HwN42BYgwjTDHDfZLsL1qSiRg84SZ6e7c9a5mAofqF9qb4wSdKbVQXmBSql32T3AzuTxjUSj9M/pqcBsEWKA99JKnvO8P9g+rPDaXs0S6xzn8wX5T7colLS1PVuAHrPCzGpyBhvlyFb8r2UwbBAm6kHqR5859mf6CudjbXF7DGpzLXKwSkg02ebzQ3MRxEHDeLsufmJhgaV4LS0GMIAEnsobgkpA3rpi155ROiW4ZTbg+5GSgme7hml3lY9xnJ+MfzDmbnlg3JT1smgWC25ToQLO0vEub7EtFEoV2go98iXzqqAATmiWdOXxcerhcWqdTIOm9VVxLFYai2YzBAl90jmtWrb1j9UZ7Zuil/ZrR8buw3m6YYITnl6Fo+CZJNNLRIFzTpKNlyKs0AiQ466d6njiBORiRMvWWurQYz3n07dd/StEOmeagUZdojLcWrC2hkR9B0+0e7B8kPpLQYZB2LMo0TOZ8AESc9ZOaL/wyuSPMAdPI9j2MY65iOY+PuzmPXgAzV2OvMVrhMWmMtxZs9nFV83ElOYZBAr8g4pyP8sEhdtbtzLodDh4EPD/zSh6u2o1qjjq/5cRuC9vZqrWC6dX2htKEHuxve67sJ9AYFxaGQUbtnMeR4KzfG8RZ5zDuZ2uVCvsGEa1AfkYZPkIkKpVUTjJsfY4RDLprXprcSOwNjmNcHBgnPeac12Gy3KIRI+6sQzKv49MxvZTiJJdhUo7f8wMueZ3wP0ZYuiPWvfrw86ijHzhcL8KnzsyzzH1KFHoBjLlnJUybWQmHffwSuQsHmeCcD/W/PQZF3FnnUCr/W4Pwg12b2Ffh/eb/hCQxhxA1D4QaZw4GRyPsRzI5XEenQOxtIEdeTjfGxYCMOef8BGCVzg5Dv/qGmYJzGJjX1QfLS9NfJv7bg8FzHoOCX55NFDW1jvv/JGO8vUAmXeQ7pRae3j3LuL+fWRf8bLNjMtxCNOzjgh/+1yap9DN+1plZy+WlnvMxxYCeXrGf89j+5FqZRgAu229lka3v+jVchlId50bGGGOMMYD/Aatlm6Ede5wZAAAAAElFTkSuQmCC' 
                style='height:60px; margin-bottom: 20px;' />
                </div>

                <p>Dear {AccountName},<br/></p>
                <p>We would like to inform you that your Market Making Obligation, were not met on {today} for the following securities: </p>
                 {htmlTable}
              
                <p><u>NOTE:</u></p>
                <p>Please be advised that failure to meet these Market Maker Obligations in future trading sessions may impact the eligibility to receive any applicable rebates for these securities.</p>
                <p>Kindly ensure you are compliant with your Market Maker obligations.<br/></p>
                <p>Regards.</p>
                <p>ADX Exchange Operations.</p>

                <style>
                    table {{
                        border-collapse: collapse;
                        width: 600px;
                        font-family: Arial, sans-serif;
                    }}
                    th, td {{
                        border: 1px solid #999;
                        padding: 8px;
                        text-align: left;
                    }}
                    th {{
                        background-color: #dbe5f1;
                    }}
                </style>
                ";

            return emailBody;
        }
        public void SendEmail(IOrganizationService service, string emailBody, EntityReference fromRef, Guid accId, string code, string accountName, string email2, string email3)
        {
            string today = DateTime.Now.ToString("dd MMMM yyyy");
            var toRecipients = new List<Entity>();
            var email = new Entity("email");
            email["subject"] = $"{code} - MM Obligations - {today}";
            email["description"] = emailBody;
            email["directioncode"] = true; // outgoing
          
            // Set sender, recipient (To)
            email["from"] = new EntityCollection(new List<Entity>
            {
                new Entity("activityparty")
                {
                    ["partyid"] =new EntityReference("queue",new Guid("15825529-dd35-ee11-bdf4-6045bd6a52bc"))
                }
            });
            if (!string.IsNullOrWhiteSpace(email2))
            {
                toRecipients.Add(new Entity("activityparty")
                {
                    ["addressused"] = email2
                });
            }

            if (!string.IsNullOrWhiteSpace(email3))
            {
                toRecipients.Add(new Entity("activityparty")
                {
                    ["addressused"] = email3
                });
            }
            if (toRecipients.Any())
            {
                email["to"] = new EntityCollection(toRecipients);
            }


            var emailId = service.Create(email);
            string cleanSubject = email.GetAttributeValue<string>("subject");
            if (!string.IsNullOrEmpty(cleanSubject) && cleanSubject.StartsWith("CRM:"))
            {
                int index = cleanSubject.IndexOf(' ');
                if (index > 0)
                {
                    cleanSubject = cleanSubject.Substring(index + 1);
                    email = new Entity("email") { Id = emailId };
                    email["subject"] = cleanSubject;
                    service.Update(email);
                }
            }

            // Send the email
            var sendRequest = new OrganizationRequest("SendEmail")
            {
                ["EmailId"] = emailId,
                ["TrackingToken"] = "",
                ["IssueSend"] = true
            };
            service.Execute(sendRequest);

        }
        public class SecurityObligation
        {
            public decimal? ObligatedRate { get; set; }
            public decimal? ActualRate { get; set; }
            public string Code { get; set; }
        }

    }
}

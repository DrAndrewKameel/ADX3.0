﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Activities.Statements;
using Microsoft.Xrm.Sdk.Query;

namespace Get_Data_FROM_NMS
{
    public class Get_Data_FROM_NMS : CodeActivity
    {
        [Input("ApiUrl")]
        [RequiredArgument]
        public InArgument<string> ApiUrl { get; set; }

        [Input("Trade Date")]
        [RequiredArgument]
        public InArgument<string> TradeDate { get; set; }
       
        protected override void Execute(CodeActivityContext context)
        {
                IWorkflowContext workflowContext = context.GetExtension<IWorkflowContext>();
                IOrganizationServiceFactory serviceFactory = context.GetExtension<IOrganizationServiceFactory>();
                IOrganizationService service = serviceFactory.CreateOrganizationService(workflowContext.UserId);
                ITracingService tracingService = context.GetExtension<ITracingService>();
            try
            {
              
                string tradeDateInput = TradeDate.Get(context);
                string apiUrl = ApiUrl.Get(context);
                tracingService.Trace("here" + apiUrl);
                tracingService.Trace("date " + tradeDateInput);
                if (!DateTime.TryParseExact(tradeDateInput, "yyyy-MM-dd", null, System.Globalization.DateTimeStyles.None, out DateTime tradeDate))
                    throw new InvalidPluginExecutionException("TradeDate must be in 'yyyy-MM-dd' format.");


                string formattedDate = tradeDate.ToString("yyyy-MM-dd");
                tracingService.Trace("date " + formattedDate);

                using (HttpClient client = new HttpClient())
                {
                    // Set headers
                    client.DefaultRequestHeaders.Add("adx-Gateway-APIKey", "98b5f8ae-ba7c-478f-bda2-b9c244fc29bd");
                    client.DefaultRequestHeaders.Add("Cookie", "INGRESSCOOKIE=1750921000.568.26.845513|44adeefb0837ffa9c13ba8760e511e9d");
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                    // ✅ Build URL-encoded body
                    var formBody = new StringContent($"tradeDate={tradeDate:yyyy-MM-dd}", Encoding.UTF8, "application/x-www-form-urlencoded");

                    HttpResponseMessage response = client.PostAsync(apiUrl, formBody).Result;

                    tracingService.Trace("HttpResponseMessage " + response.Content.ReadAsStringAsync().Result);
                    //if (!response.IsSuccessStatusCode)
                    //    throw new InvalidPluginExecutionException($"API call failed with status code: {(int)response.StatusCode} - {response.ReasonPhrase}");

                    string responseBody = response.Content.ReadAsStringAsync().Result;

                    tracingService.Trace("response body " + responseBody);

                    using (JsonDocument jsonDoc = JsonDocument.Parse(responseBody))
                    {
                        JsonElement records = jsonDoc.RootElement.GetProperty("response").GetProperty("records");

                        foreach (JsonElement record in records.EnumerateArray())
                        {
                             Entity obligation = new Entity("adx_securityobligation"); // Replace with your schema
                            var query = new QueryExpression("account");
                            string markerCode = record.GetProperty("markerMakerCode").GetString();
                            query.ColumnSet.AddColumns("adx_marketmakercode", "name");
                            query.Criteria.AddCondition("adx_accountprofiletype", ConditionOperator.Equal, 4); // market maker profile type
                            query.Criteria.AddCondition("adx_marketmakercode", ConditionOperator.Equal, markerCode);

                            var accountColl = service.RetrieveMultiple(query);
                            if (accountColl != null && accountColl.Entities.Any())
                            {
                                obligation["adx_marketmakercode"] = markerCode;
                                obligation["adx_name"] = record.GetProperty("instrumentCode").GetString();
                                var accountId = accountColl.Entities[0].Id;
                                obligation["adx_marketmakername"] = new EntityReference("account", accountId);
                                obligation["adx_obligatedresponserate"] = record.GetProperty("responseRate").GetDecimal();
                                obligation["adx_actualresponserate"] = record.GetProperty("compliancePercent").GetDecimal();

                                service.Create(obligation);
                              
                            }
                            
                        }
                    }
                }
            }
             catch(Exception ex) 
            {
                tracingService.Trace(ex.ToString());
                tracingService.Trace(ex.Message.ToString());

                throw new InvalidPluginExecutionException(ex.Message);

            }

        }
    }
}

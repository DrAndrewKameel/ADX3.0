﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ADX.CRM.UpdateNationalityByNiN
{
    public class UpdateNationalityByNiN : CodeActivity
    {
        [Input("NIN")]
        [RequiredArgument]
        public InArgument<string> NIN { get; set; }

        [Input("NationalityCode")]
        [RequiredArgument]
        public InArgument<string> NationalityCode { get; set; }
        [Output("Status Code")]
        public OutArgument<int> StatusCode { get; set; }
        [Output("Message")]
        public OutArgument<string> Message { get; set; }
      
        protected override void Execute(CodeActivityContext context)
        {
            var workflowContext = context.GetExtension<IWorkflowContext>();
            var serviceFactory = context.GetExtension<IOrganizationServiceFactory>();
            var service = serviceFactory.CreateOrganizationService(workflowContext.UserId);
            ITracingService tracingService = context.GetExtension<ITracingService>();
            var nin = NIN.Get<string>(context);
            var nationality = NationalityCode.Get<string>(context);
                    var fetchXmlCurrentUserCases = $@"
             <fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                 <entity name='contact'>
                     <attribute name='createdon'/>
                     <order attribute='fullname' descending='false'/>
                     <filter type='and'>
                         <condition attribute='adx_investornumber' operator='eq' value='{nin}'/>
                     </filter>
                 </entity>
             </fetch>";

            var contactColl = service.RetrieveMultiple(
                new FetchExpression(
                    fetchXmlCurrentUserCases));
            tracingService.Trace("Start \t " + contactColl.Entities.Count);
            if (contactColl == null || contactColl.Entities.Count == 0)
            {
                StatusCode.Set(context, "400");
                Message.Set(context, "No Contact found with Nin = " + nin);
                return;
            }

            var fetchXml = $@"<?xml version=""1.0"" encoding=""utf-16""?>
                    <fetch>
                      <entity name=""adx_country"">
                        <attribute name=""adx_countrycode"" />
                        <filter>
                          <condition attribute=""adx_countrycode"" operator=""eq"" value=""{nationality}"" />
                        </filter>
                      </entity>
                    </fetch>";
            var nationalityColl = service.RetrieveMultiple(
              new FetchExpression(
                  fetchXml));
            tracingService.Trace("Start \t " + nationalityColl.Entities.Count);
            if (nationalityColl == null || nationalityColl.Entities.Count == 0)
            {
                StatusCode.Set(context, "400");
                Message.Set(context, "No Nationality found with Code = " + nationality);
                return;
            }

            var contact = contactColl.Entities.FirstOrDefault();
            var nat = nationalityColl.Entities.FirstOrDefault();
            contact["adx_currentnationality"] = new EntityReference(nat.LogicalName, nat.Id); 
            service.Update(contact);
            StatusCode.Set(context, "200");
            Message.Set(context, "Contact Updated Successfully " );
        }
    }
}

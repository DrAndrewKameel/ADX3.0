﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADX.ValidateADXAccountCreation
{
    public class ValidateADXAccountCreation : IPlugin
    {
        public void Execute(IServiceProvider serviceProvider)
        {

            var context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            var factory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            var service = factory.CreateOrganizationService(context.UserId);
            var tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            string message = context.MessageName;

            if (context.InputParameters.Contains("Target")
                 && context.InputParameters["Target"] is Entity entity
                 && entity.LogicalName == "account")
            {
                if (entity.Attributes.Contains("adx_accountprofiletype"))
                {
                    var accountType = entity.GetAttributeValue<OptionSetValue>("adx_accountprofiletype");

                    if (accountType != null)
                    {
                        int value = accountType.Value;
                        if (value == 12) // ADX
                        {
                            var query = new QueryExpression("account")
                            {
                                ColumnSet = new ColumnSet("adx_accountprofiletype"),
                                Criteria =
                                {
                                    Conditions =
                                    {
                                        new ConditionExpression("adx_accountprofiletype", ConditionOperator.Equal, 12)
                                    }
                                }
                            };
                            var accountColl = service.RetrieveMultiple(query);
                            if (accountColl.Entities.Count > 0)
                            {
                                throw new InvalidPluginExecutionException("Only one ADX Account is allowed.");

                            }
                        }
                    }
                }
            }
            

        }
    }
}

﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ADX.CreateTasksForRemoteOnBoarding
{
    public class CreateTasksForRemoteOnBoarding : CodeActivity
    {
        [Input("Stage")]
        [ReferenceTarget("adx_remotememberstages")]
        public InArgument<EntityReference> Stage { get; set; }
        protected override void Execute(CodeActivityContext executionContext)
        {
            // Get workflow context & service
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            if (Stage == null) return;
            EntityReference stageRef = Stage.Get(executionContext);
            if (stageRef == null) return;

            var query = new QueryExpression("adx_taskactivityv2");

            // Add columns to query.ColumnSet
            query.ColumnSet.AddColumns("adx_taskname", "adx_taskorder", "statuscode");

            // Add conditions to query.Criteria
            query.Criteria.AddCondition("adx_stage", ConditionOperator.Equal, stageRef.Id);
            query.Criteria.AddCondition("adx_memberonboarding", ConditionOperator.Equal, context.PrimaryEntityId);
            var existingTasks = service.RetrieveMultiple(query); 
            if(existingTasks.Entities.Any())
            {
                throw new InvalidPluginExecutionException("Tasks have already been created for this stage.");
            }
            var fetch = $@"<?xml version='1.0' encoding='utf-16'?>
                    <fetch>
                      <entity name='adx_taskactivityv2'>
                        <attribute name='adx_taskname' />
                        <attribute name='adx_taskorder' />
                        <attribute name='statuscode' />
                        <attribute name='adx_stage' />
                        <attribute name='adx_responsibleteam' />
                        <filter>
                          <condition attribute='adx_stage' operator='eq' value='{stageRef.Id}' />
                          <condition attribute='adx_tasktype' operator='eq' value='False' />
                        </filter>
                      </entity>
                    </fetch>";

            var Fquery = new FetchExpression(fetch);
            var tasks = service.RetrieveMultiple(Fquery);
            foreach (var task in tasks.Entities)
            {
                Entity taskActivity = new Entity("adx_taskactivityv2");
                taskActivity["adx_taskname"] = task.GetAttributeValue<string>("adx_taskname");
                taskActivity["adx_memberonboarding"] = new EntityReference(context.PrimaryEntityName,context.PrimaryEntityId);
                taskActivity["adx_taskorder"] = task.GetAttributeValue<int>("adx_taskorder");
                taskActivity["statuscode"] = new OptionSetValue(task.GetAttributeValue<OptionSetValue>("statuscode").Value);
                taskActivity["adx_responsibleteam"] = task.GetAttributeValue<EntityReference>("adx_responsibleteam");
                taskActivity["adx_stage"] = task.GetAttributeValue<EntityReference>("adx_stage");
                taskActivity["adx_tasktype"] = true;
                service.Create(taskActivity);
            }



        }
    }
}
